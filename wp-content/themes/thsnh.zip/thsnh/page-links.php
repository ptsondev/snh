<?php
/*
  Template Name: Page Links
 */
?>

<?php get_template_part('sherhead_noindex'); ?>

<div id="container">
    <a href="http://www.usgeo.org/">USGeo Web Directory</a>
</div>

<?php get_footer(); ?>
